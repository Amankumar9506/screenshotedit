'use client';
import { useState, useRef, useCallback, useEffect } from 'react';
import Head from 'next/head';

export default function Home() {
  const [image, setImage] = useState(null);
  const [ocrBlocks, setOcrBlocks] = useState([]);
  const [selectedBlock, setSelectedBlock] = useState(null);
  const [zoom, setZoom] = useState(1);
  const [isProcessing, setIsProcessing] = useState(false);
  const [status, setStatus] = useState('Ready');
  const [undoStack, setUndoStack] = useState([]);
  const [previewMode, setPreviewMode] = useState(false);
  const [view, setView] = useState('editor');
  const imgRef = useRef(null);
  const fileInputRef = useRef(null);

  const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000';

  const showToast = (msg) => {
    // integrate react-hot-toast here
    console.log(msg);
  };

  const handleFile = useCallback((file) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => setImage(e.target.result);
    reader.readAsDataURL(file);
  }, []);

  const handleDrop = useCallback((e) => {
    e.preventDefault();
    handleFile(e.dataTransfer.files[0]);
  }, [handleFile]);

  const runOCR = async () => {
    if (!image) return;
    setIsProcessing(true);
    setStatus('Running OCR...');
    try {
      const blob = await fetch(image).then(r => r.blob());
      const formData = new FormData();
      formData.append('image', blob, 'screenshot.png');
      formData.append('lang', 'eng+hin');
      const res = await fetch(`${API_URL}/api/ocr`, { method: 'POST', body: formData });
      const data = await res.json();
      if (data.success) {
        setOcrBlocks(data.data.words.map(w => ({ ...w, editedText: w.text, changed: false })));
        setStatus(`OCR complete: ${data.data.words.length} blocks found`);
      }
    } catch (err) {
      setStatus('OCR failed: ' + err.message);
    } finally {
      setIsProcessing(false);
    }
  };

  const downloadImage = () => {
    if (!image || !imgRef.current) return;
    const canvas = document.createElement('canvas');
    const img = imgRef.current;
    canvas.width = img.naturalWidth;
    canvas.height = img.naturalHeight;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(img, 0, 0);
    const scaleX = img.naturalWidth / img.offsetWidth;
    const scaleY = img.naturalHeight / img.offsetHeight;
    ocrBlocks.filter(b => b.changed).forEach(b => {
      ctx.fillStyle = '#fff';
      ctx.fillRect(b.bbox.x * scaleX, b.bbox.y * scaleY, b.bbox.width * scaleX, b.bbox.height * scaleY);
      ctx.fillStyle = b.color || '#000';
      ctx.font = `${b.fontSize * scaleY}px sans-serif`;
      ctx.fillText(b.editedText, b.bbox.x * scaleX + 2, (b.bbox.y + b.bbox.height * 0.8) * scaleY);
    });
    const a = document.createElement('a');
    a.download = 'edited.png';
    a.href = canvas.toDataURL('image/png');
    a.click();
  };

  return (
    <>
      <Head><title>AI Screenshot Editor</title></Head>
      <div style={{ fontFamily: 'DM Sans, sans-serif', height: '100vh', display: 'flex', flexDirection: 'column' }}>
        {/* Nav */}
        <nav style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '0 20px', height: 52, background: '#fff', borderBottom: '1px solid #eee' }}>
          <strong>AI Screenshot Editor</strong>
          <div style={{ flex: 1 }} />
          <button onClick={runOCR} disabled={!image || isProcessing}>Run OCR</button>
          <button onClick={downloadImage} disabled={!image}>Download</button>
        </nav>
        {/* Canvas */}
        <main style={{ flex: 1, overflow: 'auto', background: '#e5e7ef', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
          onDragOver={e => e.preventDefault()} onDrop={handleDrop}>
          {!image ? (
            <div onClick={() => fileInputRef.current.click()}
              style={{ width: 480, height: 320, border: '2px dashed #3b5bdb', borderRadius: 16, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', background: '#fff' }}>
              <div style={{ fontSize: 32, marginBottom: 12 }}>📤</div>
              <div style={{ fontWeight: 600, fontSize: 18 }}>Drop screenshot here</div>
              <div style={{ color: '#888', fontSize: 14, marginTop: 6 }}>PNG, JPG, JPEG, WEBP up to 20MB</div>
            </div>
          ) : (
            <div style={{ position: 'relative', transform: `scale(${zoom})`, transformOrigin: 'center' }}>
              <img ref={imgRef} src={image} alt="screenshot" style={{ display: 'block', maxWidth: 900, borderRadius: 8 }} />
              {!previewMode && ocrBlocks.map(block => (
                <div key={block.id} onClick={() => setSelectedBlock(block)}
                  style={{ position: 'absolute', left: block.bbox.x, top: block.bbox.y, width: block.bbox.width, height: block.bbox.height,
                    border: selectedBlock?.id === block.id ? '2px solid #3b5bdb' : '1.5px solid rgba(59,91,219,0.4)',
                    background: selectedBlock?.id === block.id ? 'rgba(59,91,219,0.1)' : 'rgba(59,91,219,0.04)',
                    borderRadius: 3, cursor: 'pointer' }} />
              ))}
            </div>
          )}
        </main>
        {/* Status */}
        <div style={{ padding: '6px 20px', background: '#fff', borderTop: '1px solid #eee', fontSize: 12, color: '#888' }}>
          {status} {isProcessing && '⏳'}
        </div>
        <input ref={fileInputRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={e => handleFile(e.target.files[0])} />
      </div>
    </>
  );
}
