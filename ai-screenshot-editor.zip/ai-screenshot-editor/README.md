# AI Screenshot Editor

A full-stack AI-powered screenshot text editor with OCR, AI inpainting, and multilingual support.

---

## 🚀 Quick Start

### 1. Clone & Install

```bash
git clone https://github.com/yourname/ai-screenshot-editor
cd ai-screenshot-editor

# Backend
cd backend && npm install

# Frontend
cd ../frontend && npm install
```

### 2. Supabase Setup

1. Go to [supabase.com](https://supabase.com) → New Project
2. Go to **SQL Editor** → paste the contents of `backend/schema.sql` → Run
3. Go to **Storage** → Create bucket named `screenshots` (private) and `thumbnails` (public)
4. Go to **Authentication** → Enable Google OAuth provider
5. Copy your Project URL and API keys

### 3. Environment Variables

**Backend** — create `backend/.env`:
```env
PORT=4000
FRONTEND_URL=http://localhost:3000
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_SERVICE_KEY=your-service-role-key
```

**Frontend** — create `frontend/.env.local`:
```env
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
NEXT_PUBLIC_API_URL=http://localhost:4000
```

### 4. Run Locally

```bash
# Terminal 1 - Backend
cd backend && npm run dev

# Terminal 2 - Frontend
cd frontend && npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

---

## 📦 Project Structure

```
ai-screenshot-editor/
├── backend/
│   ├── server.js          # Express API server
│   ├── schema.sql         # Supabase database schema
│   ├── package.json
│   └── render.yaml        # Render deployment config
├── frontend/
│   ├── pages/
│   │   └── index.jsx      # Main editor page
│   ├── lib/
│   │   ├── supabase.js    # Auth helpers
│   │   └── api.js         # API client
│   ├── package.json
│   ├── next.config.js
│   ├── tailwind.config.js
│   └── vercel.json        # Vercel deployment config
└── .env.example
```

---

## 🌐 Deployment

### Frontend → Vercel

```bash
cd frontend
npx vercel --prod
```

Set these environment variables in Vercel dashboard:
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- `NEXT_PUBLIC_API_URL` (your Render backend URL)

### Backend → Render

1. Push code to GitHub
2. Go to [render.com](https://render.com) → New Web Service
3. Connect your repo, point to `backend/` directory
4. Render auto-detects `render.yaml`
5. Add environment variables in Render dashboard

---

## 🔧 API Endpoints

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | `/api/ocr` | Optional | Run OCR on image |
| POST | `/api/inpaint` | Optional | AI background fill |
| POST | `/api/enhance` | Optional | Enhance image quality |
| POST | `/api/upload` | Required | Save to Supabase Storage |
| GET | `/api/history` | Required | Edit history |
| GET | `/api/profile` | Required | User profile |
| PUT | `/api/profile` | Required | Update profile |
| GET | `/api/admin/stats` | Admin | Dashboard stats |
| GET | `/api/admin/users` | Admin | User list |

---

## 🗄️ Database Tables

- `profiles` — user profiles, plan, quotas
- `edit_history` — per-user edit sessions
- `ocr_usage` — OCR request logs
- `feedback` — user feedback
- `subscriptions` — Pro/Enterprise plans
- `advertisements` — admin-managed ads
- `guest_sessions` — guest rate limiting

---

## ✨ Features

- **OCR** via Tesseract.js (English + Hindi + Hinglish)
- **AI Inpainting** — background reconstruction after text removal
- **Image Enhancement** — normalize, sharpen, brightness/saturation
- **Undo/Redo** — full edit history stack
- **Zoom** — 20% to 300%
- **Download** — high-quality PNG export
- **Auth** — Supabase Auth (email + Google OAuth)
- **Guest Mode** — 5 free OCR scans
- **Dashboard** — edit history, stats
- **Admin Panel** — users, analytics, ads, OCR monitoring
- **Dark/Light Mode** — CSS variable based theming
- **Mobile Responsive** — works on all screen sizes

---

## 🔒 Make Yourself Admin

After creating your account via the app:

```sql
-- Run in Supabase SQL Editor
UPDATE profiles SET role = 'admin' WHERE id = 'your-user-uuid';
```

---

## 📝 License

MIT License — free to use and modify.
