-- ═══════════════════════════════════════════════════════════
-- AI Screenshot Editor - Complete Database Schema
-- Run this in Supabase SQL Editor
-- ═══════════════════════════════════════════════════════════

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ─── Profiles ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT,
  avatar_url TEXT,
  role TEXT DEFAULT 'user' CHECK (role IN ('user', 'admin', 'premium')),
  plan TEXT DEFAULT 'free' CHECK (plan IN ('free', 'pro', 'enterprise')),
  ocr_quota_used INTEGER DEFAULT 0,
  ocr_quota_limit INTEGER DEFAULT 50,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Auto-create profile on signup
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO profiles (id, full_name, avatar_url)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email),
    NEW.raw_user_meta_data->>'avatar_url'
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- ─── Edit History ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS edit_history (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  file_path TEXT NOT NULL,
  file_url TEXT,
  original_name TEXT,
  file_size INTEGER,
  edited_regions INTEGER DEFAULT 0,
  downloaded BOOLEAN DEFAULT FALSE,
  thumbnail_url TEXT,
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_edit_history_user ON edit_history(user_id);
CREATE INDEX idx_edit_history_created ON edit_history(created_at DESC);

-- ─── OCR Usage ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS ocr_usage (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES profiles(id) ON DELETE SET NULL,
  image_size INTEGER,
  word_count INTEGER,
  language TEXT,
  processing_time_ms INTEGER,
  success BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_ocr_usage_user ON ocr_usage(user_id);
CREATE INDEX idx_ocr_usage_created ON ocr_usage(created_at DESC);

-- ─── Feedback ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS feedback (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES profiles(id) ON DELETE SET NULL,
  type TEXT CHECK (type IN ('bug', 'feature', 'general', 'rating')),
  message TEXT NOT NULL,
  rating INTEGER CHECK (rating BETWEEN 1 AND 5),
  status TEXT DEFAULT 'open' CHECK (status IN ('open', 'in_progress', 'resolved', 'closed')),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─── Subscriptions ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS subscriptions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  plan TEXT NOT NULL CHECK (plan IN ('pro', 'enterprise')),
  status TEXT DEFAULT 'active' CHECK (status IN ('active', 'cancelled', 'expired', 'trial')),
  starts_at TIMESTAMPTZ DEFAULT NOW(),
  ends_at TIMESTAMPTZ,
  payment_provider TEXT,
  payment_ref TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─── Advertisements ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS advertisements (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title TEXT NOT NULL,
  image_url TEXT,
  link_url TEXT,
  placement TEXT CHECK (placement IN ('banner', 'sidebar', 'modal', 'footer')),
  active BOOLEAN DEFAULT TRUE,
  impressions INTEGER DEFAULT 0,
  clicks INTEGER DEFAULT 0,
  starts_at TIMESTAMPTZ,
  ends_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─── Guest Sessions ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS guest_sessions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  session_token TEXT UNIQUE NOT NULL,
  ocr_count INTEGER DEFAULT 0,
  ip_address TEXT,
  expires_at TIMESTAMPTZ DEFAULT (NOW() + INTERVAL '24 hours'),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─── Row Level Security ──────────────────────────────────────
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE edit_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE ocr_usage ENABLE ROW LEVEL SECURITY;
ALTER TABLE feedback ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;

-- Profiles: users can read/write their own
CREATE POLICY "Users can view own profile" ON profiles FOR SELECT USING (auth.uid() = id);
CREATE POLICY "Users can update own profile" ON profiles FOR UPDATE USING (auth.uid() = id);
CREATE POLICY "Admins can view all profiles" ON profiles FOR SELECT USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
);

-- Edit history: users own their records
CREATE POLICY "Users own edit history" ON edit_history FOR ALL USING (auth.uid() = user_id);

-- OCR usage: users own their records
CREATE POLICY "Users own OCR usage" ON ocr_usage FOR ALL USING (auth.uid() = user_id);

-- Feedback: users can insert and view own
CREATE POLICY "Users can submit feedback" ON feedback FOR INSERT WITH CHECK (TRUE);
CREATE POLICY "Users view own feedback" ON feedback FOR SELECT USING (auth.uid() = user_id);

-- Subscriptions: users own their records
CREATE POLICY "Users own subscriptions" ON subscriptions FOR SELECT USING (auth.uid() = user_id);

-- ─── Storage Buckets ─────────────────────────────────────────
-- Run these in Supabase Dashboard > Storage
-- CREATE BUCKET screenshots (public: false, file size limit: 20MB)
-- CREATE BUCKET thumbnails (public: true)

-- ─── Analytics Views ─────────────────────────────────────────
CREATE OR REPLACE VIEW admin_stats AS
SELECT
  (SELECT COUNT(*) FROM profiles WHERE role != 'admin') AS total_users,
  (SELECT COUNT(*) FROM profiles WHERE plan = 'pro') AS pro_users,
  (SELECT COUNT(*) FROM edit_history WHERE created_at > NOW() - INTERVAL '30 days') AS edits_last_30d,
  (SELECT COUNT(*) FROM ocr_usage WHERE created_at > NOW() - INTERVAL '30 days') AS ocr_last_30d,
  (SELECT COUNT(*) FROM ocr_usage WHERE success = TRUE) AS successful_ocr,
  (SELECT AVG(word_count) FROM ocr_usage) AS avg_words_per_ocr;

-- ─── Sample Admin User Setup ─────────────────────────────────
-- After creating your account via Supabase Auth, run:
-- UPDATE profiles SET role = 'admin' WHERE id = 'your-user-uuid';

COMMENT ON TABLE profiles IS 'User profiles with plan and quota tracking';
COMMENT ON TABLE edit_history IS 'History of all image editing sessions';
COMMENT ON TABLE ocr_usage IS 'OCR API usage logs for quota and analytics';
COMMENT ON TABLE advertisements IS 'Admin-managed ad placements';
