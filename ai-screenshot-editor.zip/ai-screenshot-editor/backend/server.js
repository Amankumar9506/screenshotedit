const express = require('express');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { createClient } = require('@supabase/supabase-js');
const Tesseract = require('tesseract.js');
const sharp = require('sharp');
const { v4: uuidv4 } = require('uuid');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 4000;

// Supabase client
const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

// Middleware
app.use(cors({ origin: process.env.FRONTEND_URL || '*' }));
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Multer setup for file uploads
const storage = multer.memoryStorage();
const upload = multer({
  storage,
  limits: { fileSize: 20 * 1024 * 1024 }, // 20MB
  fileFilter: (req, file, cb) => {
    const allowed = ['image/png', 'image/jpeg', 'image/jpg', 'image/webp'];
    if (allowed.includes(file.mimetype)) cb(null, true);
    else cb(new Error('Only PNG, JPG, JPEG, WEBP allowed'));
  }
});

// ─── Auth Middleware ───────────────────────────────────────────────────────────
async function requireAuth(req, res, next) {
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token) return res.status(401).json({ error: 'Unauthorized' });
  const { data: { user }, error } = await supabase.auth.getUser(token);
  if (error || !user) return res.status(401).json({ error: 'Invalid token' });
  req.user = user;
  next();
}

async function optionalAuth(req, res, next) {
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (token) {
    const { data: { user } } = await supabase.auth.getUser(token);
    req.user = user || null;
  }
  next();
}

// ─── Health Check ──────────────────────────────────────────────────────────────
app.get('/health', (req, res) => res.json({ status: 'ok', timestamp: new Date() }));

// ─── OCR Endpoint ──────────────────────────────────────────────────────────────
app.post('/api/ocr', upload.single('image'), optionalAuth, async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No image provided' });

    const imageBuffer = req.file.buffer;
    const lang = req.body.lang || 'eng+hin'; // Support English + Hindi

    // Preprocess image for better OCR
    const processedBuffer = await sharp(imageBuffer)
      .normalize()
      .sharpen()
      .toBuffer();

    // Run Tesseract OCR with word-level bounding boxes
    const result = await Tesseract.recognize(processedBuffer, lang, {
      logger: () => {},
      tessedit_pageseg_mode: Tesseract.PSM.AUTO,
      preserve_interword_spaces: '1',
    });

    // Extract words with positions
    const words = result.data.words.map(word => ({
      id: uuidv4(),
      text: word.text,
      confidence: word.confidence,
      bbox: {
        x: word.bbox.x0,
        y: word.bbox.y0,
        width: word.bbox.x1 - word.bbox.x0,
        height: word.bbox.y1 - word.bbox.y0,
      },
      fontSize: Math.round((word.bbox.y1 - word.bbox.y0) * 0.75),
      color: '#000000',
    }));

    // Extract lines for context
    const lines = result.data.lines.map(line => ({
      id: uuidv4(),
      text: line.text.trim(),
      bbox: {
        x: line.bbox.x0,
        y: line.bbox.y0,
        width: line.bbox.x1 - line.bbox.x0,
        height: line.bbox.y1 - line.bbox.y0,
      },
      words: line.words.map(w => w.text),
    }));

    // Track usage if user is logged in
    if (req.user) {
      await supabase.from('ocr_usage').insert({
        user_id: req.user.id,
        image_size: imageBuffer.length,
        word_count: words.length,
        language: lang,
      });
    }

    res.json({
      success: true,
      data: {
        fullText: result.data.text,
        words: words.filter(w => w.confidence > 30 && w.text.trim().length > 0),
        lines: lines.filter(l => l.text.length > 0),
        imageWidth: result.data.imageWidth || 0,
        imageHeight: result.data.imageHeight || 0,
        language: result.data.osd?.script || lang,
      }
    });

  } catch (err) {
    console.error('OCR error:', err);
    res.status(500).json({ error: err.message || 'OCR processing failed' });
  }
});

// ─── Image Processing: Inpaint (background fill) ──────────────────────────────
app.post('/api/inpaint', upload.single('image'), optionalAuth, async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No image provided' });

    const { regions } = req.body; // JSON array of {x,y,width,height}
    const parsedRegions = typeof regions === 'string' ? JSON.parse(regions) : regions;
    const imageBuffer = req.file.buffer;

    // Get image metadata
    const metadata = await sharp(imageBuffer).metadata();
    const { width, height } = metadata;

    // For each region, sample surrounding pixels for color fill
    // (Simple background reconstruction - in production use AI inpainting)
    let processedImage = sharp(imageBuffer);

    // Convert to raw pixel data for color sampling
    const { data, info } = await sharp(imageBuffer)
      .raw()
      .toBuffer({ resolveWithObject: true });

    const channels = info.channels;

    // Create SVG overlay to fill regions with sampled background color
    const svgRects = parsedRegions.map(region => {
      // Sample colors from edges of region
      const colors = [];
      const samplePoints = [
        { x: Math.max(0, region.x - 5), y: region.y + Math.floor(region.height / 2) },
        { x: Math.min(width - 1, region.x + region.width + 5), y: region.y + Math.floor(region.height / 2) },
        { x: region.x + Math.floor(region.width / 2), y: Math.max(0, region.y - 5) },
        { x: region.x + Math.floor(region.width / 2), y: Math.min(height - 1, region.y + region.height + 5) },
      ];

      samplePoints.forEach(pt => {
        const idx = (Math.floor(pt.y) * info.width + Math.floor(pt.x)) * channels;
        if (idx >= 0 && idx < data.length - channels) {
          colors.push({ r: data[idx], g: data[idx + 1], b: data[idx + 2] });
        }
      });

      const avgColor = colors.length > 0 ? {
        r: Math.round(colors.reduce((s, c) => s + c.r, 0) / colors.length),
        g: Math.round(colors.reduce((s, c) => s + c.g, 0) / colors.length),
        b: Math.round(colors.reduce((s, c) => s + c.b, 0) / colors.length),
      } : { r: 255, g: 255, b: 255 };

      return `<rect x="${region.x}" y="${region.y}" width="${region.width}" height="${region.height}" fill="rgb(${avgColor.r},${avgColor.g},${avgColor.b})"/>`;
    }).join('');

    const svgOverlay = Buffer.from(`<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}">${svgRects}</svg>`);

    const resultBuffer = await sharp(imageBuffer)
      .composite([{ input: svgOverlay, blend: 'over' }])
      .png()
      .toBuffer();

    const base64 = resultBuffer.toString('base64');
    res.json({ success: true, image: `data:image/png;base64,${base64}` });

  } catch (err) {
    console.error('Inpaint error:', err);
    res.status(500).json({ error: err.message });
  }
});

// ─── Image Enhancement ────────────────────────────────────────────────────────
app.post('/api/enhance', upload.single('image'), optionalAuth, async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No image provided' });

    const enhanced = await sharp(req.file.buffer)
      .normalize()
      .sharpen({ sigma: 1.5 })
      .modulate({ brightness: 1.05, saturation: 1.1 })
      .png({ quality: 95 })
      .toBuffer();

    res.json({ success: true, image: `data:image/png;base64,${enhanced.toString('base64')}` });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── Upload to Supabase Storage ───────────────────────────────────────────────
app.post('/api/upload', upload.single('image'), requireAuth, async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No image' });

    const ext = req.file.mimetype.split('/')[1];
    const fileName = `${req.user.id}/${uuidv4()}.${ext}`;

    const { data, error } = await supabase.storage
      .from('screenshots')
      .upload(fileName, req.file.buffer, { contentType: req.file.mimetype });

    if (error) throw error;

    const { data: { publicUrl } } = supabase.storage
      .from('screenshots')
      .getPublicUrl(fileName);

    // Save to edit history
    await supabase.from('edit_history').insert({
      user_id: req.user.id,
      file_path: fileName,
      file_url: publicUrl,
      original_name: req.file.originalname,
      file_size: req.file.size,
    });

    res.json({ success: true, url: publicUrl, path: fileName });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── Edit History ─────────────────────────────────────────────────────────────
app.get('/api/history', requireAuth, async (req, res) => {
  const { data, error } = await supabase
    .from('edit_history')
    .select('*')
    .eq('user_id', req.user.id)
    .order('created_at', { ascending: false })
    .limit(50);

  if (error) return res.status(500).json({ error: error.message });
  res.json({ data });
});

// ─── User Profile ─────────────────────────────────────────────────────────────
app.get('/api/profile', requireAuth, async (req, res) => {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', req.user.id)
    .single();

  if (error) return res.status(404).json({ error: 'Profile not found' });
  res.json({ data: { ...data, email: req.user.email } });
});

app.put('/api/profile', requireAuth, async (req, res) => {
  const { full_name, avatar_url } = req.body;
  const { data, error } = await supabase
    .from('profiles')
    .upsert({ id: req.user.id, full_name, avatar_url, updated_at: new Date() });

  if (error) return res.status(500).json({ error: error.message });
  res.json({ success: true, data });
});

// ─── Admin Routes ─────────────────────────────────────────────────────────────
async function requireAdmin(req, res, next) {
  const { data } = await supabase
    .from('profiles')
    .select('role')
    .eq('id', req.user.id)
    .single();
  if (data?.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
  next();
}

app.get('/api/admin/stats', requireAuth, requireAdmin, async (req, res) => {
  const [users, ocr, history] = await Promise.all([
    supabase.from('profiles').select('id', { count: 'exact' }),
    supabase.from('ocr_usage').select('id', { count: 'exact' }),
    supabase.from('edit_history').select('id', { count: 'exact' }),
  ]);

  res.json({
    totalUsers: users.count,
    totalOcrRequests: ocr.count,
    totalEdits: history.count,
  });
});

app.get('/api/admin/users', requireAuth, requireAdmin, async (req, res) => {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .order('created_at', { ascending: false });
  if (error) return res.status(500).json({ error: error.message });
  res.json({ data });
});

// ─── Error Handler ────────────────────────────────────────────────────────────
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: err.message || 'Internal Server Error' });
});

app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
module.exports = app;
